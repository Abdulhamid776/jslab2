### COMP 1073 – Client-Side JavaScript

# LAB 2

#### DESCRIPTION
Using the provided HTML, CSS, and JavaScript as a starting point, build an application that allows the user to modify the background color of the page using three slider inputs, each controlling the red, green, and blue color channels.

#### INSTRUCTIONS
Follow along with the numbered instructions inside the code comments in the provided JavaScript file.

#### EVALUATION
<table>
  <tr>
    <th><b>Criteria</b></th>
    <th><b>Mark</b></th>
  </tr>
  <tr>
    <td>The above task have been completed</td>
    <td>/4</td>
  </tr>
</table>

